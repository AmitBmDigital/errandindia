import 'package:flutter/animation.dart';

class appcolor{

  Color iconcolor= Color(0xffc8dbee);
  Color bluetextcolor= Color(0xff3c7fc6);
  Color pinkColor= Color(0xfffaecec);
  Color mainColor= Color(0xff113d6b);
  Color redColor= Color(0xffff0000);
  Color blueColor= Color(0xff66d2f8);
  Color darkBlueColor = Color(0xff091f36);
  Color greyColor = Color(0xffe0e6ec);
  Color mediumGreyColor= Color(0xff8ba0b7);
  Color skyblueColor= Color(0xffe0f6fe);
  Color lightgreyColor= Color(0xfffafafa);
  Color greenColor= Color(0xff35c77e);
  Color amberColor= Color(0xfffbc418);

}