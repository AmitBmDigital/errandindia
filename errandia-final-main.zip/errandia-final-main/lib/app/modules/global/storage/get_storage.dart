
import 'package:get_storage/get_storage.dart';

final service_provider_storage_box= GetStorage();