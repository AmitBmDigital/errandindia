class manage_review_model{

  String ?image_url;
  String ? title;
  String ? description;
  String ? Date;
  double ? rating;
  String ? tag;
  manage_review_model({this.Date, this.description , this.image_url, this.rating , this.tag , this.title,});
}