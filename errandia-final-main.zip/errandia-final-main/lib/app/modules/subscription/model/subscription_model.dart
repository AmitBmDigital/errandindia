import 'package:flutter/material.dart';

class subscription_model{


  String ? title;
  String ? cost;
  String ? Date ;
  Color ? color;
  subscription_model({this.Date, this.cost , this.title, this.color});
}