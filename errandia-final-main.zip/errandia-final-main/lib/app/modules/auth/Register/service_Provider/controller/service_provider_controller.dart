import 'package:get/get.dart';

class service_Provider_controller extends GetxController{
  
}