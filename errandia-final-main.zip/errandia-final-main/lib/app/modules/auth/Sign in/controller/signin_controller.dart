import 'package:get/get.dart';

class signIn_controller extends GetxController{

  RxBool isLogin= true.obs;
}