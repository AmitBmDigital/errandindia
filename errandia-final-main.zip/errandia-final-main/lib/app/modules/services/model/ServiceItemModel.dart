class service_widget_item {
  String? imagepath;
  int cost;
  String? type;
  String title;

  service_widget_item({
   required this.cost,
    this.imagepath,
   required this.title,
    this.type,
  });
}
